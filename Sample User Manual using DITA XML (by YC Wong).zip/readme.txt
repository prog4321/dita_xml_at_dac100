This is a project to create a sample user manual (based on the Audio Technica
AT-DAC100 digital-to-analogue converter), using DITA XML and CSS.

Please follow these steps to view the DITA files:

1. Copy and paste the 'at_dac100' folder into a location on your computer.

2. Open the 'proj_at_dac100.xpr' project in the 'at_dac100' folder, using Oxygen XML Author.

3. Open the '_b_user_manual.ditamap' bookmap that is in the same folder.
   Please read this file for more information.

The DITA files are for evaluation only - please do not distribute.  

YC Wong
dca4321@yahoo.com